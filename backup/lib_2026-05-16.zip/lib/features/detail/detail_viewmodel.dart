import 'package:emby_client/core/models/base_item_dto.dart';
import 'package:emby_client/services/repositories/media_repository_impl.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Provider for the detail page ViewModel.
///
/// Manages list-level data that does not fit the single-item cache model:
/// - Similar items
/// - Seasons & episodes
/// - Studio details (fetched individually per studio)
///
/// Core item data (title, overview, people, genres) is consumed directly
/// by section components via atomic cache providers (e.g. [itemCoreProvider],
/// [peopleProvider], [genresProvider]) and does NOT flow through this ViewModel.
final detailViewModelProvider =
    AsyncNotifierProvider.family<DetailViewModel, DetailState, String>(
  DetailViewModel.new,
);

/// State for list-level detail page data.
class DetailState {
  /// List of similar/recommended items.
  final List<BaseItemDto> similarItems;

  /// List of seasons (for series type).
  final List<BaseItemDto> seasons;

  /// List of episodes for the selected season.
  final List<BaseItemDto> episodes;

  /// Currently selected season ID.
  final String? selectedSeasonId;

  /// Studio details with images (fetched via [getStudioDetail]).
  final List<BaseItemDto> studioDetails;

  const DetailState({
    this.similarItems = const [],
    this.seasons = const [],
    this.episodes = const [],
    this.selectedSeasonId,
    this.studioDetails = const [],
  });

  DetailState copyWith({
    List<BaseItemDto>? similarItems,
    List<BaseItemDto>? seasons,
    List<BaseItemDto>? episodes,
    String? selectedSeasonId,
    List<BaseItemDto>? studioDetails,
  }) {
    return DetailState(
      similarItems: similarItems ?? this.similarItems,
      seasons: seasons ?? this.seasons,
      episodes: episodes ?? this.episodes,
      selectedSeasonId: selectedSeasonId ?? this.selectedSeasonId,
      studioDetails: studioDetails ?? this.studioDetails,
    );
  }
}

/// ViewModel for list-level detail data.
///
/// The main item data is NOT managed here — section widgets consume
/// atomic cache providers directly. This ViewModel only handles:
/// - Triggering the initial page load ([getPageDetail])
/// - Seasons / episodes for Series items
/// - Similar items
/// - Studio detail images
class DetailViewModel extends AsyncNotifier<DetailState> {
  final String itemId;

  DetailViewModel(this.itemId);

  @override
  Future<DetailState> build() async {
    final mediaRepo = ref.read(mediaRepositoryProvider);

    // Trigger the pre-load. Item data will arrive via atomic cache providers.
    // We still await it so we can read item.type and item.studios for
    // follow-up list queries.
    final item = await mediaRepo.getSeries(itemId);

    final similarResult = await mediaRepo.getSimilarItems(itemId, limit: 12);

    List<BaseItemDto> seasons = [];
    List<BaseItemDto> episodes = [];
    String? selectedSeasonId;
    if (item.type == 'Series') {
      final seasonsResult = await mediaRepo.getSeasons(itemId);
      seasons = seasonsResult.items;
      if (seasons.isNotEmpty) {
        selectedSeasonId = seasons.first.id;
        final episodesResult = await mediaRepo.getEpisodes(
          itemId,
          seasonId: selectedSeasonId,
        );
        episodes = episodesResult.items;
      }
    }

    final studioDetails = await _loadStudioDetails(item);

    return DetailState(
      similarItems: similarResult.items,
      seasons: seasons,
      episodes: episodes,
      selectedSeasonId: selectedSeasonId,
      studioDetails: studioDetails,
    );
  }

  /// Loads studio details for the given [item].
  Future<List<BaseItemDto>> _loadStudioDetails(BaseItemDto item) async {
    final studios = item.studios;
    if (studios == null || studios.isEmpty) return const [];

    final current = state.value;
    final loadedIds = current?.studioDetails.map((s) => s.id).toSet() ?? {};
    final newDetails = List<BaseItemDto>.from(current?.studioDetails ?? []);
    final mediaRepo = ref.read(mediaRepositoryProvider);

    for (final studio in studios) {
      final studioId = studio.id;
      if (studioId != null && !loadedIds.contains(studioId.toString())) {
        try {
          final detail = await mediaRepo.getStudioDetail(studioId);
          newDetails.add(detail);
        } catch (_) {
          // Ignore studio detail fetch errors
        }
      }
    }

    final latest = state.value;
    if (latest != null && newDetails.length != latest.studioDetails.length) {
      state = AsyncValue.data(latest.copyWith(studioDetails: newDetails));
    }

    return newDetails;
  }

  /// Selects a season and loads its episodes.
  Future<void> selectSeason(String seasonId) async {
    final current = state.value;
    if (current == null) return;

    final mediaRepo = ref.read(mediaRepositoryProvider);
    final episodesResult = await mediaRepo.getEpisodes(
      itemId,
      seasonId: seasonId,
    );

    state = AsyncValue.data(
      current.copyWith(
        episodes: episodesResult.items,
        selectedSeasonId: seasonId,
      ),
    );
  }
}
